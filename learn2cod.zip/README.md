# Flask-Project
Webdevelopment using Flask, Python , Bootstrap , CSS , Html and MySql Database.

<h2>Sample!</h2>

<b><h4>ScreenShots.</h4></b>
Home
![alt text](https://user-images.githubusercontent.com/61063171/93243251-92a25c80-f7a5-11ea-91c9-ca24446d69f0.png
)
Contact
![Screenshot (260)](https://user-images.githubusercontent.com/61063171/93244978-2d9c3600-f7a8-11ea-9cd3-149d09b8888a.png)
Practice
![Screenshot (259)](https://user-images.githubusercontent.com/61063171/93244984-2f65f980-f7a8-11ea-971a-dd84321b6c83.png)
About
![Screenshot (258)](https://user-images.githubusercontent.com/61063171/93244992-2ffe9000-f7a8-11ea-9a96-63eefa426dff.png)
Contact form
![Screenshot (261)](https://user-images.githubusercontent.com/61063171/93244994-312fbd00-f7a8-11ea-8d9f-21be39f006e2.png)
